/*
--------------------------------
    : Custom - Validate js :
--------------------------------
*/
"use strict";
jQuery(".form-validate").validate({
    ignore: [],
    errorClass: "invalid-feedback animated fadeInDown",
    errorElement: "div",
    errorPlacement: function(e, a) {
        jQuery(a).parents(".form-group > div").append(e);
    },
    highlight: function(e) {
        jQuery(e).closest(".form-group").removeClass("is-invalid").addClass("is-invalid");
        if ($(e).hasClass("select2-hidden-accessible")) {
            $(e).next().find(".select2-selection").addClass("is-invalid");
        }
    },
    unhighlight: function(e) {
        jQuery(e).closest(".form-group").removeClass("is-invalid");
        if ($(e).hasClass("select2-hidden-accessible")) {
            $(e).next().find(".select2-selection").removeClass("is-invalid");
        }
    },
    success: function(e) {
        jQuery(e).closest(".form-group").removeClass("is-invalid"), jQuery(e).remove();
    },
    rules: {
        "parent": {
            required: true
        },
        "pages_title": {
            required: true
        },
        "category": {
            required: true
        },
        "urlwebsite": {
            required: true
        },
        "urlcms": {
            required: true
        },
        "iconcms": {
            required: true
        },
        "language": {
            required: true
        },
        "display_sequence": {
            required: true
        }
    },
    messages: {
        "parent": {
            required: "Please select the parent"
        },
        "pages_title": {
            required: "Please enter the title"
        },
        "category": {
            required: "Please select the category"
        },
        "urlwebsite": {
            required: "Please enter url website"
        },
        "urlcms": {
            required: "Please enter url cms"
        },
        "iconcms": {
            required: "Please enter icon cms"
        },
        "language": {
            required: "Please select a language"
        },
        "display_sequence": {
            required: "Please select a display sequence"
        }
    },
    submitHandler: function(form) {
        swal({
            title: 'Save Successfully.',
            text: 'Continue to input other language?',
            type: 'success',
            showCancelButton: true,
            confirmButtonClass: 'btn btn-success',
            confirmButtonText: 'Yes Continue',
            cancelButtonClass: 'btn btn-danger m-l-10',
            cancelButtonText: 'No'
        }).then(function () {
            window.location.href = 'create_menu.php'; // Ganti dengan URL tujuan Anda
        }, function (dismiss) {
            if (dismiss === 'cancel') {
                window.location.href = 'list_menu.php'; // Ganti dengan URL tujuan Anda
            }
        })
    }
});