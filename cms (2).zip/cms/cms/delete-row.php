<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Simulasi penghapusan data
    // Di sini kita tidak menghubungkan ke database,
    // tetapi hanya memberikan respons sukses.

    $response = array('success' => true);

    echo json_encode($response);
}
?>