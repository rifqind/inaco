<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Orbiter is a bootstrap minimal & clean admin template">
    <meta name="keywords" content="admin, admin panel, admin template, admin dashboard, responsive, bootstrap 4, ui kits, ecommerce, web app, crm, cms, html, sass support, scss">
    <meta name="author" content="Themesbox">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>CMS Inaco</title>
    <!-- Fevicon -->
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <!-- Start css -->

    <!-- Sweet Alert css -->
    <link href="assets/plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="assets/css/flag-icon.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/style.css?v=<?php echo rand(); ?>" rel="stylesheet" type="text/css">
    <!-- End css -->
</head>

<body class="vertical-layout">
    <!-- Start Containerbar -->
    <div id="containerbar">
        <!-- Start Leftbar -->
        <?php include('base/leftbar.php')?>
        <!-- End Leftbar -->
        <!-- Start Rightbar -->
        <div class="rightbar">
            <!-- Start Topbar Mobile -->
            <?php include('base/topbar-mobile.php')?>
            
            <!-- Start Topbar -->
            <div class="topbar">
                <!-- Start row -->
                <div class="row align-items-center">
                    <!-- Start col -->
                    <div class="col-md-12 align-self-center">
                        <div class="togglebar">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="menubar">
                                        <a class="menu-hamburger" href="javascript:void();">
                                           <img src="assets/images/svg-icon/collapse.svg" class="img-fluid menu-hamburger-collapse" alt="collapse">
                                           <img src="assets/images/svg-icon/close.svg" class="img-fluid menu-hamburger-close" alt="close">
                                         </a>
                                     </div>
                                </li>
                            </ul>
                        </div>
                       
                    </div>
                    <!-- End col -->
                </div> 
                <!-- End row -->
            </div>
            <!-- End Topbar -->
            <!-- Start Breadcrumbbar -->                    
            <div class="breadcrumbbar">
                <div class="row align-items-center">
                    <div class="col-md-8 col-lg-8">
                        <h4 class="page-title">Add New Menu</h4>
                    </div>
                </div>          
            </div>
            <!-- End Breadcrumbbar -->
            <!-- Start Contentbar -->    
            <div class="contentbar">
                <!-- Start row -->
                <div class="row">
                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <!-- div class="card-header">
                                <h5 class="card-title">Add New</h5>
                            </div -->
                            <div class="card-body">
                                <!-- h6 class="card-subtitle">Basic form validation.</h6 -->
                                <form class="form-validate" action="#" method="post">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="parent">Parent Menu<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <select class="form-control" id="parent" name="parent" style="width:200px;">   
                                                <option value="">As Parent</option>
                                                <option value="1">Menu 1</option>
                                                <option value="2">Menu 2</option>
                                                <option value="3">Menu 3</option>
                                                <option value="4">Menu 4</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-title">Menu Title<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-title" name="pages_title" placeholder="Enter Title">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="category">Menu Category<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <select class="form-control" id="category" name="category" style="width:200px;">   
                                                <option value="">Please Select</option>
                                                <option value="1">Pages</option>
                                                <option value="2">News</option>
                                                <option value="3">Products</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-phoneus">Display on Website<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <div class="form-check form-check-inline">
                                              <input class="form-check-input" type="radio" name="page_status" id="page_status1" value="1" checked>
                                              <label class="form-check-label" for="page_status1">Yes</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                              <input class="form-check-input" type="radio" name="page_status" id="ipage_status2" value="0">
                                              <label class="form-check-label" for="page_status2">No</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="urlwebsite">URL Website<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="urlwebsite" name="urlwebsite" placeholder="Enter URL">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="urlcms">URL CMS<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="urlcms" name="urlcms" placeholder="Enter URL">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="iconcms">Icon on CMS<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="iconcmstitle" name="iconcms" placeholder="Enter Script Icon">  
                                        </div>
                                        <div class="col-lg-1  col-form-label"><a href="#" data-toggle="modal" data-target=".bd-example-modal-lg" title="INFO ICON"><i class="feather icon-info"></i></a></div>
                                        <?php include('icon_info_modal.php')?>    
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-language">Language<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <select class="form-control" id="val-language" name="language" style="width:200px;">
                                                <option value="">Please select</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="English">English</option>
                                                <option value="Arabic">Arabic</option>
                                                <option value="Vietnam">Vietnam</option>
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="display_sequence">Display Sequence<span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <select class="form-control" id="display_sequence" name="display_sequence" style="width:200px;">
                                                <option value="">Please select</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                            </select>
                                        </div>
                                    </div>                                  
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label"></label>
                                        <div class="col-lg-8">
                                            <button type="submit" class="btn btn-primary" id="submitBtn">Save</button>
                                        </div>
                                    </div>                                  
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    
                </div> <!-- End row -->
            </div>
            <!-- End Contentbar -->
            <!-- Start Footerbar -->
            <div class="footerbar">
                <footer class="footer">
                    <p class="mb-0">© <?php echo date('Y')?> Inaco - All Rights Reserved.</p>
                </footer>
            </div>
            <!-- End Footerbar -->
        </div>
        <!-- End Rightbar -->
    </div>
    <!-- End Containerbar -->
    <!-- Start js -->        
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr.min.js"></script>
    <script src="assets/js/detect.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/vertical-menu.js"></script>
    
    <!-- Select2 js -->
    <script src="assets/plugins/select2/select2.min.js"></script>
    <script src="assets/js/custom/custom-form-select.js"></script>  

    <!-- Parsley js -->
    <script src="assets/plugins/validatejs/validate.min.js"></script>
    <!-- Validate js -->
    <script src="assets/js/custom/custom-menu-form.js"></script>
    <script src="assets/js/custom/custom-form-validation.js"></script>
    
    <!-- Sweet-Alert js -->
    <script src="assets/plugins/sweet-alert2/sweetalert2.min.js"></script>

    <!-- Model js -->
    <script src="assets/js/custom/custom-model.js"></script>

    <!-- Code Mirror JS -->
    <!--script src="assets/plugins/code-mirror/codemirror.js"></script>
    <script src="assets/plugins/code-mirror/htmlmixed.js"></script>
    <script src="assets/plugins/code-mirror/css.js"></script>
    <script src="assets/plugins/code-mirror/javascript.js"></script>
    <script src="assets/plugins/code-mirror/xml.js"></script-->

    <!-- Core js -->
    <script src="assets/js/core.js"></script>
    <!-- End js -->
</body>
</html>