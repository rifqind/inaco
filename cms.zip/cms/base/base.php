<!DOCTYPE html>
<html lang="en">
<?php include('head.php')?>

<body class="vertical-layout">
    <!-- Start Containerbar -->
    <div id="containerbar">
        <!-- Start Leftbar -->
        <?php include('leftbar.php')?>
        <!-- End Leftbar -->
        <!-- Start Rightbar -->
        <div class="rightbar">
            <!-- Start Topbar Mobile -->
            <div class="topbar-mobile">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="mobile-logobar">
                            <a href="index.html" class="mobile-logo"><img src="assets/images/logo.svg" class="img-fluid" alt="logo"></a>
                        </div>
                        <div class="mobile-togglebar">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="topbar-toggle-icon">
                                        <a class="topbar-toggle-hamburger" href="javascript:void();">
                                            <img src="assets/images/svg-icon/horizontal.svg" class="img-fluid menu-hamburger-horizontal" alt="horizontal">
                                            <img src="assets/images/svg-icon/verticle.svg" class="img-fluid menu-hamburger-vertical" alt="verticle">
                                         </a>
                                     </div>
                                </li>
                                <li class="list-inline-item">
                                    <div class="menubar">
                                        <a class="menu-hamburger" href="javascript:void();">
                                            <img src="assets/images/svg-icon/collapse.svg" class="img-fluid menu-hamburger-collapse" alt="collapse">
                                            <img src="assets/images/svg-icon/close.svg" class="img-fluid menu-hamburger-close" alt="close">
                                         </a>
                                     </div>
                                </li>                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Start Topbar -->
            <div class="topbar">
                <!-- Start row -->
                <div class="row align-items-center">
                    <!-- Start col -->
                    <div class="col-md-12 align-self-center">
                        <div class="togglebar">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="menubar">
                                        <a class="menu-hamburger" href="javascript:void();">
                                           <img src="assets/images/svg-icon/collapse.svg" class="img-fluid menu-hamburger-collapse" alt="collapse">
                                           <img src="assets/images/svg-icon/close.svg" class="img-fluid menu-hamburger-close" alt="close">
                                         </a>
                                     </div>
                                </li>
                            </ul>
                        </div>
                       
                    </div>
                    <!-- End col -->
                </div> 
                <!-- End row -->
            </div>
            <!-- End Topbar -->
            <!-- Start Breadcrumbbar -->                    
            <div class="breadcrumbbar">
                <div class="row align-items-center">
                    <div class="col-md-8 col-lg-8">
                        <h4 class="page-title">Layouts</h4>
                    </div>
                </div>          
            </div>
            <!-- End Breadcrumbbar -->
            <!-- Start Contentbar -->    
            <div class="contentbar">
                <!-- Start row -->
                <div class="row">
                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Form row</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">You may also swap <code class="highlighter-rouge">.row</code> for <code class="highlighter-rouge">.form-row</code>, a variation of our standard grid row that overrides the default column gutters for tighter and more compact layouts.</h6>
                                <form>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Email</label>
                                            <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputPassword4">Password</label>
                                            <input type="password" class="form-control" id="inputPassword4" placeholder="Password">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputAddress">Address</label>
                                        <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
                                    </div>
                                    <div class="form-group">
                                        <label for="inputAddress2">Address 2</label>
                                        <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputCity">City</label>
                                            <input type="text" class="form-control" id="inputCity">
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputState">State</label>
                                            <select id="inputState" class="form-control">
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="inputZip">Zip</label>
                                            <input type="text" class="form-control" id="inputZip">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="gridCheck">
                                            <label class="form-check-label" for="gridCheck">
                                            Check me out
                                            </label>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Sign in</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Start col -->
                    <div class="col-lg-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Date & Time</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>type="datetime-local"</code></h6>
                                <div class="form-group mb-0">
                                    <input type="datetime-local" class="form-control" name="inputDateTime" id="inputDateTime">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Date</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>type="date"</code></h6>
                                <div class="form-group mb-0">
                                    <input type="date" class="form-control" name="inputDate" id="inputDate">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">File</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>type="file"</code></h6>
                                <div class="form-group mb-0">
                                    <input type="file" class="form-control-file" id="exampleFormControlFile1">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Single Select</h5>
                            </div>
                            <div class="card-body">
                                <select class="select2-single form-control" name="state">
                                    <option>Select</option>
                                    <optgroup label="Alaskan/Hawaiian Time Zone">
                                        <option value="AK">Alaska</option>
                                        <option value="HI">Hawaii</option>
                                    </optgroup>
                                    <optgroup label="Pacific Time Zone">
                                        <option value="CA">California</option>
                                        <option value="NV">Nevada</option>
                                        <option value="OR">Oregon</option>
                                        <option value="WA">Washington</option>
                                    </optgroup>
                                    <optgroup label="Mountain Time Zone">
                                        <option value="AZ">Arizona</option>
                                        <option value="CO">Colorado</option>
                                        <option value="ID">Idaho</option>
                                        <option value="MT">Montana</option>
                                        <option value="NE">Nebraska</option>
                                        <option value="NM">New Mexico</option>
                                        <option value="ND">North Dakota</option>
                                        <option value="UT">Utah</option>
                                        <option value="WY">Wyoming</option>
                                    </optgroup>
                                    <optgroup label="Central Time Zone">
                                        <option value="AL">Alabama</option>
                                        <option value="AR">Arkansas</option>
                                        <option value="IL">Illinois</option>
                                        <option value="IA">Iowa</option>
                                        <option value="KS">Kansas</option>
                                        <option value="KY">Kentucky</option>
                                        <option value="LA">Louisiana</option>
                                        <option value="MN">Minnesota</option>
                                        <option value="MS">Mississippi</option>
                                        <option value="MO">Missouri</option>
                                        <option value="OK">Oklahoma</option>
                                        <option value="SD">South Dakota</option>
                                        <option value="TX">Texas</option>
                                        <option value="TN">Tennessee</option>
                                        <option value="WI">Wisconsin</option>
                                    </optgroup>
                                    <optgroup label="Eastern Time Zone">
                                        <option value="CT">Connecticut</option>
                                        <option value="DE">Delaware</option>
                                        <option value="FL">Florida</option>
                                        <option value="GA">Georgia</option>
                                        <option value="IN">Indiana</option>
                                        <option value="ME">Maine</option>
                                        <option value="MD">Maryland</option>
                                        <option value="MA">Massachusetts</option>
                                        <option value="MI">Michigan</option>
                                        <option value="NH">New Hampshire</option>
                                        <option value="NJ">New Jersey</option>
                                        <option value="NY">New York</option>
                                        <option value="NC">North Carolina</option>
                                        <option value="OH">Ohio</option>
                                        <option value="PA">Pennsylvania</option>
                                        <option value="RI">Rhode Island</option>
                                        <option value="SC">South Carolina</option>
                                        <option value="VT">Vermont</option>
                                        <option value="VA">Virginia</option>
                                        <option value="WV">West Virginia</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div>  
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Multiple Select</h5>
                            </div>
                            <div class="card-body">
                                <select class="select2-multi-select form-control" name="states[]" multiple="multiple">
                                    <optgroup label="Alaskan/Hawaiian Time Zone">
                                        <option value="AK">Alaska</option>
                                        <option value="HI">Hawaii</option>
                                    </optgroup>
                                    <optgroup label="Pacific Time Zone">
                                        <option value="CA">California</option>
                                        <option value="NV">Nevada</option>
                                        <option value="OR">Oregon</option>
                                        <option value="WA">Washington</option>
                                    </optgroup>
                                    <optgroup label="Mountain Time Zone">
                                        <option value="AZ">Arizona</option>
                                        <option value="CO">Colorado</option>
                                        <option value="ID">Idaho</option>
                                        <option value="MT">Montana</option>
                                        <option value="NE">Nebraska</option>
                                        <option value="NM">New Mexico</option>
                                        <option value="ND">North Dakota</option>
                                        <option value="UT">Utah</option>
                                        <option value="WY">Wyoming</option>
                                    </optgroup>
                                    <optgroup label="Central Time Zone">
                                        <option value="AL">Alabama</option>
                                        <option value="AR">Arkansas</option>
                                        <option value="IL">Illinois</option>
                                        <option value="IA">Iowa</option>
                                        <option value="KS">Kansas</option>
                                        <option value="KY">Kentucky</option>
                                        <option value="LA">Louisiana</option>
                                        <option value="MN">Minnesota</option>
                                        <option value="MS">Mississippi</option>
                                        <option value="MO">Missouri</option>
                                        <option value="OK">Oklahoma</option>
                                        <option value="SD">South Dakota</option>
                                        <option value="TX">Texas</option>
                                        <option value="TN">Tennessee</option>
                                        <option value="WI">Wisconsin</option>
                                    </optgroup>
                                    <optgroup label="Eastern Time Zone">
                                        <option value="CT">Connecticut</option>
                                        <option value="DE">Delaware</option>
                                        <option value="FL">Florida</option>
                                        <option value="GA">Georgia</option>
                                        <option value="IN">Indiana</option>
                                        <option value="ME">Maine</option>
                                        <option value="MD">Maryland</option>
                                        <option value="MA">Massachusetts</option>
                                        <option value="MI">Michigan</option>
                                        <option value="NH">New Hampshire</option>
                                        <option value="NJ">New Jersey</option>
                                        <option value="NY">New York</option>
                                        <option value="NC">North Carolina</option>
                                        <option value="OH">Ohio</option>
                                        <option value="PA">Pennsylvania</option>
                                        <option value="RI">Rhode Island</option>
                                        <option value="SC">South Carolina</option>
                                        <option value="VT">Vermont</option>
                                        <option value="VA">Virginia</option>
                                        <option value="WV">West Virginia</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div>  
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Default Tags</h5>
                            </div>
                            <div class="card-body">
                                <input type="text" id="tagsinput-default" class="form-control" value="Amsterdam,Washington,Sydney" data-role="tagsinput" />
                            </div>
                        </div>
                    </div>  
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Typeahead Tags</h5>
                            </div>
                            <div class="card-body">
                                <input type="text" id="tagsinput-typehead" class="form-control"  value="Amsterdam,Washington" data-role="tagsinput" />
                            </div>
                        </div>
                    </div>  
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-12">
                        <h5 class="card-title font-18">Input type with different sizes</h5>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Default Size</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>.form-control-md</code></h6>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="inputDefaultSize" id="inputDefaultSize" placeholder="Default input">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Small Size</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>.form-control-sm</code></h6>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-sm" name="inputSmallSize" id="inputSmallSize" placeholder="Small input">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Large Size</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>.form-control-lg</code></h6>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-lg" name="inputLargeSize" id="inputLargeSize" placeholder="Large input">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Grid Sizes</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Usage <code>.col-sm-4</code></h6>
                                <div class="form-group row">
                                    <label class="col-sm-2 control-label">Grid Sizes</label>
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" placeholder=".col-sm-4">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 offset-sm-2">
                                        <input type="text" class="form-control" placeholder=".col-sm-6">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-8 offset-sm-2">
                                        <input type="text" class="form-control" placeholder=".col-sm-8">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-10 offset-sm-2">
                                        <input type="text" class="form-control" placeholder=".col-sm-10">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->

                     <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Inline Checkbox</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Group checkboxes or radios on the same horizontal row by adding <code class="highlighter-rouge">.form-check-inline</code> to any <code class="highlighter-rouge">.form-check</code>.</h6>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                                  <label class="form-check-label" for="inlineCheckbox1">1</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                  <label class="form-check-label" for="inlineCheckbox2">2</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3" disabled>
                                  <label class="form-check-label" for="inlineCheckbox3">3 (disabled)</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Custom Inline Checkbox</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Group checkboxes or radios on the same horizontal row by adding <code class="highlighter-rouge">.custom-control-inline</code>.</h6>
                                <div class="custom-control custom-checkbox custom-control-inline">
                                  <input type="checkbox" id="customCheckboxInline1" name="customCheckboxInline1" class="custom-control-input">
                                  <label class="custom-control-label" for="customCheckboxInline1">1</label>
                                </div>
                                <div class="custom-control custom-checkbox custom-control-inline">
                                  <input type="checkbox" id="customCheckboxInline2" name="customCheckboxInline2" class="custom-control-input">
                                  <label class="custom-control-label" for="customCheckboxInline2">2</label>
                                </div>
                                <div class="custom-control custom-checkbox custom-control-inline">
                                  <input type="checkbox" id="customCheckboxInline3" name="customCheckboxInline3" class="custom-control-input" disabled>
                                  <label class="custom-control-label" for="customCheckboxInline3">3 (disabled)</label>
                                </div>
                                <div class="custom-checkbox-button mt-3">
                                    <h5 class="font-16">Custom Color Checkbox</h5>
                                    <div class="form-check-inline checkbox-primary">
                                      <input type="checkbox" id="customCheckboxInline5" name="customCheckboxInline2" checked>
                                      <label for="customCheckboxInline5"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-secondary">
                                      <input type="checkbox" id="customCheckboxInline6" name="customCheckboxInline2">
                                      <label for="customCheckboxInline6"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-success">
                                      <input type="checkbox" id="customCheckboxInline7" name="customCheckboxInline2">
                                      <label for="customCheckboxInline7"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-danger">
                                      <input type="checkbox" id="customCheckboxInline8" name="customCheckboxInline2">
                                      <label for="customCheckboxInline8"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-warning">
                                      <input type="checkbox" id="customCheckboxInline9" name="customCheckboxInline2">
                                      <label for="customCheckboxInline9"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-info">
                                      <input type="checkbox" id="customCheckboxInline10" name="customCheckboxInline2">
                                      <label for="customCheckboxInline10"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-light">
                                      <input type="checkbox" id="customCheckboxInline11" name="customCheckboxInline2">
                                      <label for="customCheckboxInline11"></label>
                                    </div>
                                    <div class="form-check-inline checkbox-dark">
                                      <input type="checkbox" id="customCheckboxInline12" name="customCheckboxInline2">
                                      <label for="customCheckboxInline12"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->

                    <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Inline Radios</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Group checkboxes or radios on the same horizontal row by adding <code class="highlighter-rouge">.form-check-inline</code> to any <code class="highlighter-rouge">.form-check</code>.</h6>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                                  <label class="form-check-label" for="inlineRadio1">Active</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                                  <label class="form-check-label" for="inlineRadio2">In Active</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" disabled>
                                  <label class="form-check-label" for="inlineRadio3">3 (disabled)</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Custom Inline Radios</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Group checkboxes or radios on the same horizontal row by adding <code class="highlighter-rouge">.custom-control-inline</code>.</h6>
                                <div class="custom-control custom-radio custom-control-inline">
                                  <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadioInline1">1</label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline">
                                  <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadioInline2">2</label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" id="customRadioInline3" name="customRadioInline1" class="custom-control-input" disabled>
                                    <label class="custom-control-label" for="customRadioInline3">3</label>
                                </div>
                                <div class="custom-radio-button mt-3">
                                    <h5 class="font-16">Custom Color Radio</h5>
                                    <div class="form-check-inline radio-primary">
                                      <input type="radio" id="customRadioInline5" name="customRadioInline2" checked>
                                      <label for="customRadioInline5"></label>
                                    </div>
                                    <div class="form-check-inline radio-secondary">
                                      <input type="radio" id="customRadioInline6" name="customRadioInline2">
                                      <label for="customRadioInline6"></label>
                                    </div>
                                    <div class="form-check-inline radio-success">
                                      <input type="radio" id="customRadioInline7" name="customRadioInline2">
                                      <label for="customRadioInline7"></label>
                                    </div>
                                    <div class="form-check-inline radio-danger">
                                      <input type="radio" id="customRadioInline8" name="customRadioInline2">
                                      <label for="customRadioInline8"></label>
                                    </div>
                                    <div class="form-check-inline radio-warning">
                                      <input type="radio" id="customRadioInline9" name="customRadioInline2">
                                      <label for="customRadioInline9"></label>
                                    </div>
                                    <div class="form-check-inline radio-info">
                                      <input type="radio" id="customRadioInline10" name="customRadioInline2">
                                      <label for="customRadioInline10"></label>
                                    </div>
                                    <div class="form-check-inline radio-light">
                                      <input type="radio" id="customRadioInline11" name="customRadioInline2">
                                      <label for="customRadioInline11"></label>
                                    </div>
                                    <div class="form-check-inline radio-dark">
                                      <input type="radio" id="customRadioInline12" name="customRadioInline2">
                                      <label for="customRadioInline12"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->

                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Basic Bottons</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Bootstrap includes several predefined button styles, each serving its own semantic purpose, with a few extras thrown in for more control.</h6>
                                <div class="button-list">
                                    <button type="button" class="btn btn-primary">Primary</button>
                                    <button type="button" class="btn btn-secondary">Secondary</button>
                                    <button type="button" class="btn btn-success">Success</button>
                                    <button type="button" class="btn btn-danger">Danger</button>
                                    <button type="button" class="btn btn-warning">Warning</button>
                                    <button type="button" class="btn btn-info">Info</button>
                                    <button type="button" class="btn btn-light">Light</button>
                                    <button type="button" class="btn btn-dark">Dark</button>
                                    <button type="button" class="btn btn-link">Link</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Rounded Bottons</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Bootstrap includes several predefined button styles, each serving its own semantic purpose, with a few extras thrown in for more control.</h6>
                                <div class="button-list">
                                    <button type="button" class="btn btn-rounded btn-primary">Primary</button>
                                    <button type="button" class="btn btn-rounded btn-secondary">Secondary</button>
                                    <button type="button" class="btn btn-rounded btn-success">Success</button>
                                    <button type="button" class="btn btn-rounded btn-danger">Danger</button>
                                    <button type="button" class="btn btn-rounded btn-warning">Warning</button>
                                    <button type="button" class="btn btn-rounded btn-info">Info</button>
                                    <button type="button" class="btn btn-rounded btn-light">Light</button>
                                    <button type="button" class="btn btn-rounded btn-dark">Dark</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->

                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Bottons with Icon</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Bootstrap includes several predefined button styles, each serving its own semantic purpose, with a few extras thrown in for more control.</h6>
                                <div class="button-list">
                                    <button type="button" class="btn btn-primary"><i class="feather icon-send mr-2"></i> Submit</button>
                                    <button type="button" class="btn btn-secondary"><i class="feather icon-save mr-2"></i> Save</button>
                                    <button type="button" class="btn btn-success"><i class="feather icon-plus mr-2"></i> Insert</button>
                                    <button type="button" class="btn btn-warning"><i class="feather icon-upload mr-2"></i> Update</button>
                                    <button type="button" class="btn btn-danger"><i class="feather icon-trash-2 mr-2"></i> Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Rounded Bottons with Only Icon</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Bootstrap includes several predefined button styles, each serving its own semantic purpose, with a few extras thrown in for more control.</h6>
                                <div class="button-list">
                                    <button type="button" class="btn btn-round btn-primary"><i class="feather icon-send"></i> </button>
                                    <button type="button" class="btn btn-round btn-secondary"><i class="feather icon-save"></i> </button>
                                    <button type="button" class="btn btn-round btn-success"><i class="feather icon-plus"></i> </button>
                                    <button type="button" class="btn btn-round btn-warning"><i class="feather icon-upload"></i></button>
                                    <button type="button" class="btn btn-round btn-danger"><i class="feather icon-trash-2"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->

                    <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Form Validation</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">Basic form validation.</h6>
                                <form class="form-validate" action="#" method="post">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-username">User ID <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-username" name="val-username" placeholder="Enter User ID">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-email">Email <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-email" name="val-email" placeholder="Enter Email ID">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-password">Password <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="password" class="form-control" id="val-password" name="val-password" placeholder="Enter Password">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-confirm-password">Re-Type Password <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="password" class="form-control" id="val-confirm-password" name="val-confirm-password" placeholder="Enter again passward for confirm">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-suggestions">Description <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <textarea class="form-control" id="val-suggestions" name="val-suggestions" rows="5" placeholder="Enter Your Details."></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-skill">Skill <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <select class="form-control" id="val-skill" name="val-skill">
                                                <option value="">Please select</option>
                                                <option value="web-development">Web Development</option>
                                                <option value="web-designing">Web Designing</option>
                                                <option value="ui-designing">UI Designing</option>
                                                <option value="marketing">Marketing</option>
                                                <option value="testing">Testing</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-currency">Currency <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-currency" name="val-currency" placeholder="$45.75">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-website">Website <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-website" name="val-website" placeholder="http://demo.com">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-phoneus">Phone <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-phoneus" name="val-phoneus" placeholder="999-888-0000">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-digits">Digits <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-digits" name="val-digits" placeholder="9">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-number">Number <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-number" name="val-number" placeholder="9.1">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label" for="val-range">Range [1, 5] <span class="text-danger">*</span></label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="val-range" name="val-range" placeholder="3">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label">Terms &amp; Conditions <span class="text-danger">*</span></label>
                                        <div class="col-lg-8">
                                            <label class="css-control css-control-primary css-checkbox" for="val-terms">
                                                <input type="checkbox" class="css-control-input" id="val-terms" name="val-terms" value="1">
                                                <span class="css-control-indicator"></span> I agree to the terms & conditions of Orbiter
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label"></label>
                                        <div class="col-lg-8">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>                                  
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6 col-xl-4">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title">Image Thumbnails</h5>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle">In addition to our border-radius utilities, you can use <code class="highlighter-rouge">.img-thumbnail</code> to give an image a rounded 1px border appearance.</h6>
                                <img src="assets/images/ui-images/image-thumbnail.jpg" alt="Thumbnail Image" class="img-thumbnail">
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    
                    <!-- Start col -->
                    <div class="col-lg-6 col-xl-3">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Sweet Alert.  Warning message, with the "Confirm" Button</h5>
                            </div>
                            <div class="card-body">
                                <div class="sweet-alert">
                                    <button type="button" class="btn btn-primary" id="sa-warning">Delete Record</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    <!-- Start col -->
                    <div class="col-lg-6 col-xl-3">
                        <div class="card m-b-30">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Sweet Alert.  Success message with ok button</h5>
                            </div>
                            <div class="card-body">
                                <div class="sweet-alert">
                                    <button type="button" class="btn btn-primary" id="sa-success-auto-close">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End col -->
                    
                </div> <!-- End row -->
            </div>
            <!-- End Contentbar -->
            <!-- Start Footerbar -->
            <div class="footerbar">
                <footer class="footer">
                    <p class="mb-0">© <?php echo date('Y')?> Inaco - All Rights Reserved.</p>
                </footer>
            </div>
            <!-- End Footerbar -->
        </div>
        <!-- End Rightbar -->
    </div>
    <!-- End Containerbar -->
    <!-- Start js -->        
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr.min.js"></script>
    <script src="assets/js/detect.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/vertical-menu.js"></script>
    <!-- Select2 js -->
    <script src="assets/plugins/select2/select2.min.js"></script>    
    <!-- Tagsinput js -->
    <script src="assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
    <script src="assets/plugins/bootstrap-tagsinput/typeahead.bundle.js"></script>
    <script src="assets/js/custom/custom-form-select.js"></script>
    <!-- Parsley js -->
    <script src="assets/plugins/validatejs/validate.min.js"></script>
    <!-- Validate js -->
    <script src="assets/js/custom/custom-validate.js"></script>
    <script src="assets/js/custom/custom-form-validation.js"></script>
    <!-- Sweet-Alert js -->
    <script src="assets/plugins/sweet-alert2/sweetalert2.min.js"></script>
    <script src="assets/js/custom/custom-sweet-alert.js"></script>
    <!-- Core js -->
    <script src="assets/js/core.js"></script>
    <!-- End js -->
</body>
</html>